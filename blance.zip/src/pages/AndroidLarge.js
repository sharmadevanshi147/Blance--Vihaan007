import TopNav from "../components/TopNav";
import FrameComponent2 from "../components/FrameComponent2";
import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent from "../components/FrameComponent";
import "./AndroidLarge.css";

const AndroidLarge = () => {
  return (
    <div className="android-large-3">
      <TopNav />
      <section className="android-large-3-inner">
        <div className="frame-parent">
          <FrameComponent2 />
          <div className="frame-wrapper">
            <div className="suggestions-for-you-parent">
              <div className="suggestions-for-you">Suggestions for you</div>
              <div className="frame-container">
                <div className="frame-group">
                  <div className="text-wrapper">
                    <div className="text">
                      <p className="cardio-for-20">{`Cardio for 20 `}</p>
                      <p className="minutes-on-a">{`minutes on a daily basis is a `}</p>
                      <p className="great-hobby">great hobby</p>
                    </div>
                  </div>
                  <div className="text-container">
                    <div className="text1">
                      Decreasing time by 8 minutes daily can get you extra coins
                    </div>
                  </div>
                </div>
              </div>
              <div className="stay-updated-with">
                Stay Updated with your friend’s activity
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="frame-section">
        <FrameComponent1 />
        <FrameComponent />
      </section>
    </div>
  );
};

export default AndroidLarge;
