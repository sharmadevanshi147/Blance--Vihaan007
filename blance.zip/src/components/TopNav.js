import { useCallback } from "react";
import "./TopNav.css";

const TopNav = () => {
  const onPersonIconClick = useCallback(() => {
    // Please sync "Android Large - 12" to the project
  }, []);

  return (
    <section className="top-nav">
      <header className="status-bar-ios-iphone">
        <div className="action">
          <div className="time">9:41</div>
        </div>
        <div className="right-wrapper">
          <div className="right">
            <img
              className="icon-mobile-signal"
              loading="lazy"
              alt=""
              src="/icon--mobile-signal.svg"
            />
            <img className="wifi-icon" alt="" src="/wifi.svg" />
            <img
              className="statusbar-battery-icon"
              loading="lazy"
              alt=""
              src="/-statusbarbattery.svg"
            />
          </div>
        </div>
      </header>
      <div className="frame-div">
        <div className="vector-parent">
          <img className="vector-icon" alt="" src="/vector.svg" />
          <div className="store-1">Store 1</div>
        </div>
        <img className="chevron-down-icon" alt="" src="/chevron-down.svg" />
      </div>
      <div className="top-nav-inner">
        <div className="frame-parent1">
          <div className="frame-wrapper1">
            <div className="frame-parent2">
              <div className="wrapper-group-1244830185-parent">
                <div className="wrapper-group-1244830185">
                  <img
                    className="wrapper-group-1244830185-child"
                    alt=""
                    src="/group-1244830185.svg"
                  />
                </div>
                <img
                  className="person-icon"
                  loading="lazy"
                  alt=""
                  src="/person.svg"
                  onClick={onPersonIconClick}
                />
              </div>
              <h1 className="balnce">
                <span className="balnce1">Balnce</span>
                <span className="span">.</span>
              </h1>
            </div>
          </div>
          <div className="wrapper-frame-1244834249">
            <img
              className="wrapper-frame-1244834249-child"
              loading="lazy"
              alt=""
              src="/frame-1244834249@2x.png"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default TopNav;
