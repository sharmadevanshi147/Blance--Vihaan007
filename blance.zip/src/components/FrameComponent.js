import { useCallback } from "react";
import "./FrameComponent.css";

const FrameComponent = () => {
  const onFrameContainerClick = useCallback(() => {
    // Please sync "Android Large - 6" to the project
  }, []);

  const onGroupIconClick = useCallback(() => {
    // Please sync "Android Large - 7" to the project
  }, []);

  return (
    <div className="rectangle-group">
      <div className="component-child" />
      <footer className="frame-footer">
        <div className="frame-wrapper5">
          <div className="frame-parent7">
            <div className="frame-parent8">
              <div className="frame-wrapper6">
                <div className="frame-wrapper7">
                  <div className="frame-parent9">
                    <div className="frame-wrapper8">
                      <div className="ellipse-parent">
                        <div className="ellipse-div" />
                        <div className="home">Home</div>
                        <img className="icon-frame" loading="lazy" alt="" />
                      </div>
                    </div>
                    <img className="general-home-1" alt="" />
                    <img
                      className="general-home-2"
                      alt=""
                      src="/general--home-2.svg"
                    />
                  </div>
                </div>
              </div>
              <div className="frame-wrapper9">
                <div className="frame-parent10" onClick={onFrameContainerClick}>
                  <div className="frame-wrapper10">
                    <div className="frame-parent11">
                      <div className="frame-wrapper11">
                        <img
                          className="group-icon"
                          alt=""
                          src="/group-1244830512.svg"
                        />
                      </div>
                      <div className="friends">Friends</div>
                    </div>
                  </div>
                  <img
                    className="user-users-group"
                    loading="lazy"
                    alt=""
                    src="/user--users-group.svg"
                  />
                </div>
              </div>
              <div className="frame-wrapper12">
                <div className="frame-parent12">
                  <div className="frame-wrapper13">
                    <div className="frame-parent13">
                      <div className="frame-wrapper14">
                        <div className="frame-parent14">
                          <img
                            className="frame-child8"
                            alt=""
                            src="/group-1244830512.svg"
                          />
                          <img className="financewallet-icon" alt="" />
                        </div>
                      </div>
                      <div className="rewards">Rewards</div>
                    </div>
                  </div>
                  <img
                    className="general-category-1"
                    loading="lazy"
                    alt=""
                    src="/general--category-1.svg"
                  />
                </div>
              </div>
              <div className="frame-parent15">
                <div className="frame-parent16">
                  <div className="frame-wrapper15">
                    <div className="frame-parent17">
                      <img
                        className="frame-child9"
                        alt=""
                        src="/group-1244830512.svg"
                        onClick={onGroupIconClick}
                      />
                      <img className="financewallet-icon1" alt="" />
                    </div>
                  </div>
                  <div className="offers">Offers</div>
                </div>
                <img className="icon" loading="lazy" alt="" src="/icon.svg" />
              </div>
            </div>
            <div className="frame-parent18">
              <div className="frame-wrapper16">
                <div className="frame-parent19">
                  <div className="frame-wrapper17">
                    <img
                      className="frame-child10"
                      alt=""
                      src="/group-1244830512.svg"
                    />
                  </div>
                  <div className="analytics">Analytics</div>
                </div>
              </div>
              <img
                className="frame-child11"
                loading="lazy"
                alt=""
                src="/group-1244830519.svg"
              />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default FrameComponent;
