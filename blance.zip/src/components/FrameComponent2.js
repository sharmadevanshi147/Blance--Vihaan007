import "./FrameComponent2.css";

const FrameComponent2 = () => {
  return (
    <div className="rectangle-parent">
      <div className="frame-child" />
      <div className="frame-wrapper2">
        <div className="todays-usage-parent">
          <b className="todays-usage">Today’s Usage</b>
          <div className="image-1-parent">
            <img
              className="image-1-icon"
              loading="lazy"
              alt=""
              src="/image-1@2x.png"
            />
            <div className="hooray-you">Hooray ! You met your targets !</div>
          </div>
        </div>
      </div>
      <div className="depth-4-frame-0" />
      <div className="frame-parent3">
        <div className="frame-parent4">
          <div className="k-parent">
            <div className="k">10hr</div>
            <div className="div">7hr</div>
            <div className="div1">5hr</div>
            <div className="div2">3hr</div>
            <div className="div3">2 hr</div>
            <div className="div4">1 hr</div>
          </div>
          <div className="frame-wrapper3">
            <div className="group-div">
              <div className="frame-parent5">
                <div className="frame-item" />
                <div className="frame-inner" />
                <div className="frame-child1" />
                <div className="frame-child2" />
                <div className="frame-child3" />
                <div className="frame-child4" />
                <div className="frame-child5" />
                <div className="line-div" />
              </div>
              <div className="frame-child6" />
              <div className="frame-child7" />
            </div>
          </div>
        </div>
        <div className="k-group">
          <div className="k1">Mon</div>
          <div className="div5">Tue</div>
          <div className="div6">Wed</div>
          <div className="div7">Thu</div>
          <div className="div8">Fri</div>
          <div className="div9">Sat</div>
          <div className="div10">Sun</div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent2;
