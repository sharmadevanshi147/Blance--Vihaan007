import "./FrameComponent1.css";

const FrameComponent1 = () => {
  return (
    <div className="frame-wrapper4">
      <div className="frame-parent6">
        <div className="ellipse-wrapper">
          <img
            className="ellipse-icon"
            loading="lazy"
            alt=""
            src="/ellipse-131@2x.png"
          />
        </div>
        <div className="friend-circle">
          <div className="jane-doe">Jane Doe</div>
          <div className="jane-activity">
            <div className="succcessfully-managed-to">
              Succcessfully Managed to keep her instagram time to 30 mins.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent1;
